from __future__ import print_function
import sys
import os
import pkgutil
import pkg_resources
import pyspark
def main():
    print("\n just testing")

if __name__ == "__main__":
  main()
